<?php
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);

    try {
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];

            if ($remember) {
                $token = bin2hex(random_bytes(32));
                $expiry = date('Y-m-d H:i:s', strtotime('+30 days'));
                
                $stmt = $db->prepare("UPDATE users SET remember_token = ?, token_expiry = ? WHERE id = ?");
                $stmt->execute([$token, $expiry, $user['id']]);
                
                setcookie('remember_token', $token, strtotime('+30 days'), '/', '', true, true);
            }

            $_SESSION['message'] = 'Добро пожаловать, ' . htmlspecialchars($user['username']) . '!';
            $_SESSION['message_type'] = 'success';
            header('Location: index.php');
            exit;
        } else {
            $_SESSION['message'] = 'Неверное имя пользователя или пароль';
            $_SESSION['message_type'] = 'error';
            header('Location: index.php');
            exit;
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Ошибка при входе: ' . $e->getMessage();
        $_SESSION['message_type'] = 'error';
        header('Location: index.php');
        exit;
    }
}

if (!isset($_SESSION['user_id']) && isset($_COOKIE['remember_token'])) {
    $token = $_COOKIE['remember_token'];
    
    $stmt = $db->prepare("SELECT * FROM users WHERE remember_token = ? AND token_expiry > NOW()");
    $stmt->execute([$token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        
        $newToken = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+30 days'));
        
        $stmt = $db->prepare("UPDATE users SET remember_token = ?, token_expiry = ? WHERE id = ?");
        $stmt->execute([$newToken, $expiry, $user['id']]);
        
        setcookie('remember_token', $newToken, strtotime('+30 days'), '/', '', true, true);
        
        $_SESSION['message'] = 'С возвращением, ' . htmlspecialchars($user['username']) . '!';
        $_SESSION['message_type'] = 'success';
        header('Location: index.php');
        exit;
    }
}
?>