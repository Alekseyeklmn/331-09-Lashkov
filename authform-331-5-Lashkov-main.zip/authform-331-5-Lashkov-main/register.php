<?php
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = $_POST['password'];
    
    if (!preg_match('/^[A-Za-z0-9]{2,32}$/', $username)) {
        $_SESSION['message'] = 'Имя пользователя должно содержать только латинские буквы и цифры (от 2 до 32 символов)';
        $_SESSION['message_type'] = 'error';
        header('Location: index.php');
        exit;
    }

    if (!preg_match('/^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{4,16}$/', $password)) {
        $_SESSION['message'] = 'Пароль должен содержать от 4 до 16 символов, включая заглавную букву, цифру и специальный символ';
        $_SESSION['message_type'] = 'error';
        header('Location: index.php');
        exit;
    }

    $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetchColumn() > 0) {
        $_SESSION['message'] = 'Пользователь с таким именем уже существует';
        $_SESSION['message_type'] = 'error';
        header('Location: index.php');
        exit;
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    try {
        $stmt = $db->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->execute([$username, $hashedPassword]);
        
        $_SESSION['message'] = 'Регистрация успешно завершена! Теперь вы можете войти.';
        $_SESSION['message_type'] = 'success';
        header('Location: index.php');
        exit;
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Ошибка при регистрации: ' . $e->getMessage();
        $_SESSION['message_type'] = 'error';
        header('Location: index.php');
        exit;
    }
}
?>